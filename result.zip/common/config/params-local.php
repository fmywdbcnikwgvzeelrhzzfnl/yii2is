<?php
return [
    'front_domain' => "localhost",
    'front_scheme' => "http://",
];
