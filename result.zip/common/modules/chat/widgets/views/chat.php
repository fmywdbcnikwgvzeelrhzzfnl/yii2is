<script>
   /* var conn = new WebSocket('ws://localhost:8080');
    conn.onopen = function (e) {
        console.log("Connection established!");
    };

    conn.onmessage = function (e) {
        console.log(e.data);
    };*/
</script>

<textarea cols="20" rows="10" id="chatMessages">

</textarea>

<?php
/**
 * Created by PhpStorm.
 * User: Миша_2
 * Date: 30.08.2018
 * Time: 0:05
 */